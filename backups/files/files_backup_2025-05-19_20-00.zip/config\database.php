<?php

return [
    'host' => 'localhost',
    'dbname' => 'compte_restaurant_scolaire',
    'user' => 'root',
    'password' => 'root',
    'port' => '3306'
];
