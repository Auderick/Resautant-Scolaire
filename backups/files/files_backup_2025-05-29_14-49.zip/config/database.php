<?php

// Configuration fixe pour l'application Electron
return [
    'host' => '127.0.0.1',
    'dbname' => 'gestion_restaurant_scolaire',
    'user' => 'root',
    'password' => 'root',
    'port' => '3307'
];
