<?php

return [
    'host' => 'localhost',
    'dbname' => 'database_name',
    'user' => 'username',
    'password' => 'password',
    'port' => '3306'
];
